package com.example.demo.Service;

import com.example.demo.Entity.Bikes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BikesRepo extends JpaRepository<Bikes,Integer> {
}

package com.example.demo.Entity;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.web.multipart.MultipartFile;

public class BikesDTO {

    @NotEmpty(message = "The model is required")
    private String model;

    @NotEmpty(message = "The type  is required ")
    private String type;

    @Min(0)
    private Long cost;

    @Min(0)
    private Integer year;

    @Size(min=10,message = "Description should be atleast 10 Characters")
    @Size(max =2000 , message = "Description exceeds 2000 Characters")
    private String desc;

    private MultipartFile image ;



    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getCost() {
        return cost;
    }

    public void setCost(Long cost) {
        this.cost = cost;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public MultipartFile getImage() {
        return image;
    }

    public void setImage(MultipartFile image) {
        this.image = image;
    }
}

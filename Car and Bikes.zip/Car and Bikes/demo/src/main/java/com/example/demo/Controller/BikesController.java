package com.example.demo.Controller;

import com.example.demo.Entity.Bikes;
import com.example.demo.Entity.BikesDTO;
import com.example.demo.Service.BikesRepo;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.List;

@Controller
//@RequestMapping("/products")
public class BikesController {

    @Autowired
    private BikesRepo bikesRepo;
    @RequestMapping("/products")


    @GetMapping({" ","/"})
    public String ShowBikes(Model model)
    {
        List<Bikes> products = bikesRepo.findAll();
        model.addAttribute("products",products);
        return "index";

    }
    @GetMapping("/create")
    public String ShowCreate(Model model)
    {
        BikesDTO bikesDTO = new BikesDTO();
        model.addAttribute("bikesDTO",bikesDTO);
        return "create";
    }
    @PostMapping("/create")
    public String createProduct(
        @Valid @ModelAttribute BikesDTO bikesDTO,
        BindingResult result){

        if(bikesDTO.getImage().isEmpty())
        {
            result.addError(new FieldError("bikesDTO","image","The image file is not uploaded"));
        }
        if(result.hasErrors())
        {
            return "create";
        }

        MultipartFile image = bikesDTO.getImage();
        Date created = new Date();
        String filename = created.getTime() + "_"+image.getOriginalFilename();

        try {
            String uploaddir= "public/images/";
            Path uploadpath = Paths.get(uploaddir); //save the image

            if(!Files.exists(uploadpath))
            {
                Files.createDirectories(uploadpath);
            }
            try(InputStream inputStream = image.getInputStream())
            {
                Files.copy(inputStream,Paths.get(uploaddir + filename), StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (Exception ex)
        {
            System.out.print("Exception " +ex.getMessage() );
        }
        Bikes bikes = new Bikes();
        bikes.setModel(bikesDTO.getModel());
        bikes.setCost(bikesDTO.getCost());
        bikes.setType(bikesDTO.getType());
        bikes.setYear(bikesDTO.getYear());
        bikes.setDesc(bikesDTO.getDesc());
        bikes.setImage(filename);

        bikesRepo.save(bikes);
        return "redirect:/products";
    }

    @GetMapping("/edit")

        public String Showedit(
                Model model,
        @RequestParam int id
            )
    {
        try {
            Bikes bikes = bikesRepo.findById(id).get();
            model.addAttribute("bikes",bikes);

            BikesDTO bikesDTO =new BikesDTO();
            bikesDTO.setModel(bikes.getModel());
            bikesDTO.setCost(bikes.getCost());
            bikesDTO.setType(bikes.getType());
            bikesDTO.setYear(bikes.getYear());
            bikesDTO.setDesc(bikes.getDesc());

            model.addAttribute("bikesDTO",bikesDTO);

        }
        catch(Exception ex)
        {
            System.out.print("Exception " +ex.getMessage() );
            return "redirect:/products";
        }
        return "edit";
    }

    @PostMapping("/edit")
    public String updateedit(
            Model model,
            @RequestParam int id,
            @Valid @ModelAttribute BikesDTO bikesDTO,
            BindingResult result)
    {

        try {
            Bikes bikes= bikesRepo.findById(id).get();
            model.addAttribute("bikes",bikes);
            if(result.hasErrors())
            {
                return "edit";
            }

            if(!bikesDTO.getImage().isEmpty())
            {
                //delete old image file
                String updir = "public/images/";
                Path oldpath = Paths.get(updir+ bikes.getImage());
                try {
                    Files.delete(oldpath);
                }
                catch (Exception ex)
                {
                    System.out.print(ex.getMessage());
                }

                //save new image
                MultipartFile image= bikesDTO.getImage();
                Date createdAt=new Date();
                String Filename=createdAt.getTime()+"_"+image.getOriginalFilename();
                try(InputStream inputStream = image.getInputStream())
                {
                    Files.copy(inputStream,Paths.get(updir+Filename),
                            StandardCopyOption.REPLACE_EXISTING);
                }
                bikes.setImage(Filename);

            }
            bikes.setModel(bikesDTO.getModel());
            bikes.setCost(bikesDTO.getCost());
            bikes.setType(bikesDTO.getType());
            bikes.setYear(bikesDTO.getYear());
            bikes.setDesc(bikesDTO.getDesc());
            bikesRepo.save(bikes);
        }
        catch(Exception ex)
        {
            System.out.print("Exception " +ex.getMessage() );
//            return "redirect:/products";
        }
        return "redirect:/products";
    }

    @GetMapping("/delete")
    public String deletebike(
            @RequestParam int id)
    {
        try {
            Bikes bikes = bikesRepo.findById(id).get();
             Path imagepath = Paths.get("public/images/" + bikes.getImage());

             try {
                 Files.delete(imagepath);
             }
             catch (Exception ex)
             {
                 System.out.print("Exception " +ex.getMessage() );
             }
             bikesRepo.delete(bikes);

        }
        catch(Exception ex)
        {
            System.out.print("Exception " +ex.getMessage() );
//            return "redirect:/products";
        }
        return "redirect:/products";
    }



}

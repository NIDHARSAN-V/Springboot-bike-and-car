package com.example.demo.Entity;

import jakarta.persistence.*;


@Entity
@Table(name = "Bikes")
public class Bikes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "B_model")
    private String model;
    @Column(name = "B_type")
    private String type;
    @Column(name = "B_cost")
    private Long  cost;
    @Column(name = "year")
    private  Integer year;

    @Column(name = "B_desc")
    private String desc;
    @Column(name="B_img")
    private String image;

    public Bikes(Integer id, String model, String type, Long cost, Integer year, String desc, String image) {
        this.id = id;
        this.model = model;
        this.type = type;
        this.cost = cost;
        this.year = year;
        this.desc = desc;
        this.image = image;
    }

    public Bikes() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Long getCost() {
        return cost;
    }

    public void setCost(Long cost) {
        this.cost = cost;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}
